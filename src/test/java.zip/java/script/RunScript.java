package script;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import utilities.Loader;
import application.Login;
import utilities.Playback;

public class RunScript {

	public Login login;
	public Loader loader;
	
	
	@BeforeSuite
	public void beforeRunSuite(ITestContext testContext) {
		Playback.testContext = testContext;
	}
	@BeforeMethod
	public void beforeTestMethod(ITestContext testContext, ITestResult testResult) {
		Playback.testContext = testContext;
		Playback.start();
		login = new Login();
		loader = new Loader();
	}
	@Test
	public void test1() {
		login.loginScreen.Logon();
		loader.navigateToModule("Audit");
	}
	
	public void afterTestMethod() {
		Playback.stop();
		login.Reset();
	}
}
