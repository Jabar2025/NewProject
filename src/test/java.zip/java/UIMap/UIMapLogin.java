package UIMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utilities.Playback;

public class UIMapLogin {

	
	public LoginScreen loginScreen;
	
	public UIMapLogin() {
		if (this.loginScreen == null)
			this.loginScreen = new LoginScreen();
	}
	
	public class LoginScreen {
	
	public LoginScreen() {
     PageFactory.initElements(Playback.driver, this);   
    }
	@FindBy(how = How.ID, using = "username")
	public WebElement emailAddressEdit;

	@FindBy(how = How.ID, using = "password")
	public WebElement passwordEdit;
	
	@FindBy(how = How.ID, using = "signinbutton")
	public WebElement loginButton;
}
}