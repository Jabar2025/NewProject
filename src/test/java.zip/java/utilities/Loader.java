package utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Loader {
	
	
	public void navigateToModule(String moduleName) {
		try {
			WebElement element = Playback.driver.findElement(By.xpath(
					"//div[@class='grid grid-cols-1 gap-4 transition-all duration-300 ease-in-out sm:grid-cols-2 sm:gap-6 md:grid-cols-3 lg:grid-cols-4']//a[contains(@href, '"
							+ moduleName + "')]"));
			if (element.isDisplayed()) {
				element.click();
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
