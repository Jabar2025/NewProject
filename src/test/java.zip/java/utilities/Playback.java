package utilities;

import java.util.Collections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestContext;
import org.testng.ITestResult;

import resources.PropertiesFile;

public class Playback {

	public static ITestContext testContext;
	public static ITestResult testResult;
	public static WebDriver driver;
	
	public static String BrowserType = PropertiesFile.readPropertiesFile("BrowserType");
	public static String driverPath = PropertiesFile.readPropertiesFile("driverPath");
	public static String Url = PropertiesFile.readPropertiesFile("url");
	
	public static void StartDriver() {

		//chromeDriver
		System.setProperty("webdriver.chrome.driver", driverPath + "\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.merge(option);
		option.addArguments("--disable-popup-blocking");
		option.addArguments("--disable-notifications");
		option.addArguments("disable-infobars");
		option.addArguments("--disable-translate");
		option.addArguments("--remote-allow-origins=*");
		option.setExperimentalOption("useAutomationExtension", false);
		option.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		driver = new ChromeDriver(option);
		driver.manage().window().maximize();
	}
	
	public static void start() {
		Playback.StartDriver();
	}

	public static void stop() {
		Playback.driver.manage().deleteAllCookies();
		Playback.driver.quit();
		}
	}
	

